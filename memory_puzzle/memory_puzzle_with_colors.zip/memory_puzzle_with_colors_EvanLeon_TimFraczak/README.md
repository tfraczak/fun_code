1. Go into terminal
2. cd to ../memory_puzzle/
3. run 'ruby game.rb' in terminal